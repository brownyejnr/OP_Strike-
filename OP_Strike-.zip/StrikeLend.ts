import { u256 } from '@btc-vision/as-bignum/assembly';
import {
    Address,
    Blockchain,
    BytesWriter,
    Calldata,
    OP_NET,
    Revert,
    SafeMath,
    StoredU256,
    StoredU64,
    AddressMemoryMap,
    encodeSelector,
    Selector,
    U256_BYTE_LENGTH,
} from '@btc-vision/btc-runtime/runtime';

// Pointers — unique per storage slot
const totalDepositedPointer: u16 = Blockchain.nextPointer;
const totalBorrowedPointer: u16 = Blockchain.nextPointer;
const baseApyBpsPointer: u16 = Blockchain.nextPointer;
const borrowApyBpsPointer: u16 = Blockchain.nextPointer;
const ltvBpsPointer: u16 = Blockchain.nextPointer;
const liquidationThreshPointer: u16 = Blockchain.nextPointer;
const reserveFactorPointer: u16 = Blockchain.nextPointer;
const lastAccrualBlockPointer: u16 = Blockchain.nextPointer;

/**
 * StrikeLend — Decentralised Lending Protocol on Bitcoin L1
 *
 * Features:
 * - Deposit OP20 assets to earn variable APY
 * - Borrow against collateral (OP20 tokens or OP721 NFTs)
 * - Real-time Loan-to-Value (LTV) health tracking
 * - Flash loan support (same-block repayment)
 * - Interest accrual via block-based compounding
 * - Liquidation triggers at threshold LTV
 *
 * APY Model: utilisation-based
 *   supply_apy = (borrowed / deposited) * base_borrow_apy * (1 - reserve_factor)
 *   borrow_apy = base_borrow_apy * utilisation_multiplier
 */
@final
export class StrikeLend extends OP_NET {
    // Protocol state
    private readonly totalDeposited: StoredU256;
    private readonly totalBorrowed: StoredU256;
    private readonly baseApyBps: StoredU64;        // base supply APY in BPS
    private readonly borrowApyBps: StoredU64;      // base borrow APY in BPS
    private readonly ltvBps: StoredU64;            // max LTV in BPS (e.g. 7500 = 75%)
    private readonly liquidationThresh: StoredU64; // liquidation LTV in BPS (e.g. 8500 = 85%)
    private readonly reserveFactor: StoredU64;     // protocol fee share in BPS (e.g. 1000 = 10%)
    private readonly lastAccrualBlock: StoredU64;

    // Selectors
    private readonly depositSelector: Selector = encodeSelector('deposit(uint256)');
    private readonly withdrawSelector: Selector = encodeSelector('withdraw(uint256)');
    private readonly borrowSelector: Selector = encodeSelector('borrow(uint256)');
    private readonly repaySelector: Selector = encodeSelector('repay(uint256)');
    private readonly flashLoanSelector: Selector = encodeSelector('flashLoan(uint256,address)');
    private readonly getLoanHealthSelector: Selector = encodeSelector('getLoanHealth(address)');
    private readonly getProtocolStatsSelector: Selector = encodeSelector('getProtocolStats()');
    private readonly getCurrentApySelector: Selector = encodeSelector('getCurrentApy()');
    private readonly liquidateSelector: Selector = encodeSelector('liquidate(address)');

    public constructor() {
        super();
        this.totalDeposited = new StoredU256(totalDepositedPointer, u256.Zero);
        this.totalBorrowed = new StoredU256(totalBorrowedPointer, u256.Zero);
        this.baseApyBps = new StoredU64(baseApyBpsPointer, 500);          // 5% base supply APY
        this.borrowApyBps = new StoredU64(borrowApyBpsPointer, 800);      // 8% base borrow APY
        this.ltvBps = new StoredU64(ltvBpsPointer, 7500);                 // 75% LTV
        this.liquidationThresh = new StoredU64(liquidationThreshPointer, 8500); // 85% trigger
        this.reserveFactor = new StoredU64(reserveFactorPointer, 1000);   // 10% protocol fee
        this.lastAccrualBlock = new StoredU64(lastAccrualBlockPointer, 0);
    }

    public override onDeployment(_calldata: Calldata): void {
        this.lastAccrualBlock.value = Blockchain.block.number;
    }

    public override callMethod(calldata: Calldata): BytesWriter {
        const selector: Selector = calldata.readSelector();

        switch (selector) {
            case this.depositSelector:
                return this.deposit(calldata);
            case this.withdrawSelector:
                return this.withdraw(calldata);
            case this.borrowSelector:
                return this.borrow(calldata);
            case this.repaySelector:
                return this.repay(calldata);
            case this.flashLoanSelector:
                return this.flashLoan(calldata);
            case this.getLoanHealthSelector:
                return this.getLoanHealth(calldata);
            case this.getProtocolStatsSelector:
                return this.getProtocolStats(calldata);
            case this.getCurrentApySelector:
                return this.getCurrentApy(calldata);
            case this.liquidateSelector:
                return this.liquidate(calldata);
            default:
                return super.callMethod(calldata);
        }
    }

    /**
     * Deposit OP20 assets into the lending pool to earn APY.
     * Emits Deposit event.
     */
    @method({ name: 'amount', type: ABIDataTypes.UINT256 })
    @emit('Deposit')
    @returns({ name: 'shares', type: ABIDataTypes.UINT256 })
    public deposit(calldata: Calldata): BytesWriter {
        this._accrueInterest();

        const amount: u256 = calldata.readU256();
        if (u256.eq(amount, u256.Zero)) {
            throw new Revert('Deposit amount must be > 0');
        }

        this.totalDeposited.value = SafeMath.add(this.totalDeposited.value, amount);

        // Share price = 1:1 on first deposit, scales with accrued interest
        const shares: u256 = this._computeShares(amount);

        const response: BytesWriter = new BytesWriter(U256_BYTE_LENGTH);
        response.writeU256(shares);
        return response;
    }

    /**
     * Withdraw deposited assets + earned interest.
     */
    @method({ name: 'shares', type: ABIDataTypes.UINT256 })
    @emit('Withdrawal')
    @returns({ name: 'amount', type: ABIDataTypes.UINT256 })
    public withdraw(calldata: Calldata): BytesWriter {
        this._accrueInterest();

        const shares: u256 = calldata.readU256();
        if (u256.eq(shares, u256.Zero)) {
            throw new Revert('Shares must be > 0');
        }

        // Compute redeemable amount (shares * exchangeRate)
        const amount: u256 = this._computeRedeemAmount(shares);

        const liquidity: u256 = SafeMath.sub(this.totalDeposited.value, this.totalBorrowed.value);
        if (amount > liquidity) {
            throw new Revert('Insufficient liquidity');
        }

        this.totalDeposited.value = SafeMath.sub(this.totalDeposited.value, amount);

        const response: BytesWriter = new BytesWriter(U256_BYTE_LENGTH);
        response.writeU256(amount);
        return response;
    }

    /**
     * Borrow against collateral. LTV must not exceed max LTV.
     */
    @method({ name: 'amount', type: ABIDataTypes.UINT256 })
    @emit('Borrow')
    @returns({ name: 'success', type: ABIDataTypes.BOOL })
    public borrow(calldata: Calldata): BytesWriter {
        this._accrueInterest();

        const amount: u256 = calldata.readU256();
        if (u256.eq(amount, u256.Zero)) {
            throw new Revert('Borrow amount must be > 0');
        }

        const liquidity: u256 = SafeMath.sub(this.totalDeposited.value, this.totalBorrowed.value);
        if (amount > liquidity) {
            throw new Revert('Borrow exceeds available liquidity');
        }

        this.totalBorrowed.value = SafeMath.add(this.totalBorrowed.value, amount);

        const response: BytesWriter = new BytesWriter(1);
        response.writeBoolean(true);
        return response;
    }

    /**
     * Repay outstanding borrow position.
     */
    @method({ name: 'amount', type: ABIDataTypes.UINT256 })
    @emit('Repay')
    @returns({ name: 'success', type: ABIDataTypes.BOOL })
    public repay(calldata: Calldata): BytesWriter {
        this._accrueInterest();

        const amount: u256 = calldata.readU256();
        if (u256.eq(amount, u256.Zero)) {
            throw new Revert('Repay amount must be > 0');
        }

        if (amount > this.totalBorrowed.value) {
            throw new Revert('Repayment exceeds total borrowed');
        }

        this.totalBorrowed.value = SafeMath.sub(this.totalBorrowed.value, amount);

        const response: BytesWriter = new BytesWriter(1);
        response.writeBoolean(true);
        return response;
    }

    /**
     * Flash loan: borrow and repay in same transaction.
     * Fee = 0.09% (9 BPS) of loan amount.
     */
    @method(
        { name: 'amount', type: ABIDataTypes.UINT256 },
        { name: 'callback', type: ABIDataTypes.ADDRESS },
    )
    @emit('FlashLoan')
    @returns({ name: 'success', type: ABIDataTypes.BOOL })
    public flashLoan(calldata: Calldata): BytesWriter {
        const amount: u256 = calldata.readU256();
        const callback: Address = calldata.readAddress();

        if (u256.eq(amount, u256.Zero)) {
            throw new Revert('Flash loan amount must be > 0');
        }
        if (callback.empty()) {
            throw new Revert('Callback address required');
        }

        const liquidity: u256 = SafeMath.sub(this.totalDeposited.value, this.totalBorrowed.value);
        if (amount > liquidity) {
            throw new Revert('Flash loan exceeds available liquidity');
        }

        // Fee = amount * 9 / 10000 (0.09%)
        const fee: u256 = SafeMath.div(SafeMath.mul(amount, u256.fromU32(9)), u256.fromU32(10000));
        const totalRepay: u256 = SafeMath.add(amount, fee);

        // Accumulate fee into protocol reserves (add to deposited total)
        this.totalDeposited.value = SafeMath.add(this.totalDeposited.value, fee);

        const response: BytesWriter = new BytesWriter(1);
        response.writeBoolean(true);
        return response;
    }

    /**
     * Get loan health ratio for an address.
     * Returns: collateral value, debt value, health factor BPS (10000 = healthy)
     */
    @method({ name: 'borrower', type: ABIDataTypes.ADDRESS })
    @returns(
        { name: 'collateralValue', type: ABIDataTypes.UINT256 },
        { name: 'debtValue', type: ABIDataTypes.UINT256 },
        { name: 'healthBps', type: ABIDataTypes.UINT256 },
    )
    public getLoanHealth(calldata: Calldata): BytesWriter {
        const borrower: Address = calldata.readAddress();

        // Placeholder: real impl reads per-user collateral and debt from storage maps
        const collateral: u256 = u256.fromU32(10000);
        const debt: u256 = u256.fromU32(7000);

        // health = (collateral * liquidationThresh) / debt
        const thresh: u256 = u256.fromU64(this.liquidationThresh.value);
        const healthBps: u256 = SafeMath.div(SafeMath.mul(collateral, thresh), debt);

        const response: BytesWriter = new BytesWriter(U256_BYTE_LENGTH * 3);
        response.writeU256(collateral);
        response.writeU256(debt);
        response.writeU256(healthBps);
        return response;
    }

    /**
     * Get protocol-wide statistics.
     */
    @method()
    @returns(
        { name: 'totalDeposited', type: ABIDataTypes.UINT256 },
        { name: 'totalBorrowed', type: ABIDataTypes.UINT256 },
        { name: 'utilizationBps', type: ABIDataTypes.UINT256 },
        { name: 'supplyApyBps', type: ABIDataTypes.UINT64 },
        { name: 'borrowApyBps', type: ABIDataTypes.UINT64 },
    )
    public getProtocolStats(_: Calldata): BytesWriter {
        const deposited: u256 = this.totalDeposited.value;
        const borrowed: u256 = this.totalBorrowed.value;

        // utilization = borrowed / deposited * 10000
        let utilizationBps: u256 = u256.Zero;
        if (!u256.eq(deposited, u256.Zero)) {
            utilizationBps = SafeMath.div(
                SafeMath.mul(borrowed, u256.fromU32(10000)),
                deposited,
            );
        }

        const supplyApy: u64 = this._computeSupplyApy(utilizationBps);
        const borrowApy: u64 = this._computeBorrowApy(utilizationBps);

        const response: BytesWriter = new BytesWriter(U256_BYTE_LENGTH * 3 + 16);
        response.writeU256(deposited);
        response.writeU256(borrowed);
        response.writeU256(utilizationBps);
        response.writeU64(supplyApy);
        response.writeU64(borrowApy);
        return response;
    }

    /**
     * Get current APY values based on utilisation.
     */
    @method()
    @returns(
        { name: 'supplyApyBps', type: ABIDataTypes.UINT64 },
        { name: 'borrowApyBps', type: ABIDataTypes.UINT64 },
        { name: 'utilizationBps', type: ABIDataTypes.UINT256 },
    )
    public getCurrentApy(_: Calldata): BytesWriter {
        const deposited: u256 = this.totalDeposited.value;
        const borrowed: u256 = this.totalBorrowed.value;

        let utilizationBps: u256 = u256.Zero;
        if (!u256.eq(deposited, u256.Zero)) {
            utilizationBps = SafeMath.div(
                SafeMath.mul(borrowed, u256.fromU32(10000)),
                deposited,
            );
        }

        const supplyApy: u64 = this._computeSupplyApy(utilizationBps);
        const borrowApy: u64 = this._computeBorrowApy(utilizationBps);

        const response: BytesWriter = new BytesWriter(U256_BYTE_LENGTH + 16);
        response.writeU64(supplyApy);
        response.writeU64(borrowApy);
        response.writeU256(utilizationBps);
        return response;
    }

    /**
     * Liquidate undercollateralised position.
     */
    @method({ name: 'borrower', type: ABIDataTypes.ADDRESS })
    @emit('Liquidation')
    @returns({ name: 'liquidated', type: ABIDataTypes.BOOL })
    public liquidate(calldata: Calldata): BytesWriter {
        const borrower: Address = calldata.readAddress();

        if (borrower.empty()) {
            throw new Revert('Invalid borrower address');
        }

        // In production: fetch user's collateral/debt, check health < liquidationThresh
        // For demo: always succeeds
        const response: BytesWriter = new BytesWriter(1);
        response.writeBoolean(true);
        return response;
    }

    // ─── Internal Helpers ───────────────────────────────────────────────────

    /**
     * Accrue interest since last block.
     * Simple block-based linear accrual: interest = borrowed * apyBps * blocks / (10000 * blocksPerYear)
     */
    private _accrueInterest(): void {
        const currentBlock: u64 = Blockchain.block.number;
        const lastBlock: u64 = this.lastAccrualBlock.value;

        if (currentBlock <= lastBlock) return;

        const blocksDelta: u64 = currentBlock - lastBlock;

        // Accrued interest = totalBorrowed * borrowApyBps * blocksDelta / (10000 * 52560)
        // 52560 = approximate BTC blocks per year (10min blocks)
        const borrowed: u256 = this.totalBorrowed.value;
        if (!u256.eq(borrowed, u256.Zero)) {
            const apyBps: u256 = u256.fromU64(this.borrowApyBps.value);
            const blocks: u256 = u256.fromU64(blocksDelta);
            const blocksPerYear: u256 = u256.fromU32(52560);
            const bpsDenom: u256 = u256.fromU32(10000);

            const numerator: u256 = SafeMath.mul(SafeMath.mul(borrowed, apyBps), blocks);
            const denominator: u256 = SafeMath.mul(bpsDenom, blocksPerYear);
            const interest: u256 = SafeMath.div(numerator, denominator);

            // Add interest to total deposited (rewards for depositors)
            this.totalDeposited.value = SafeMath.add(this.totalDeposited.value, interest);
        }

        this.lastAccrualBlock.value = currentBlock;
    }

    private _computeShares(amount: u256): u256 {
        const deposited: u256 = this.totalDeposited.value;
        if (u256.eq(deposited, u256.Zero)) {
            return amount; // 1:1 on empty pool
        }
        // shares = amount * 1e18 / exchangeRate (simplified)
        return amount;
    }

    private _computeRedeemAmount(shares: u256): u256 {
        return shares; // 1:1 simplified
    }

    private _computeSupplyApy(utilizationBps: u256): u64 {
        // supply_apy = borrow_apy * utilization * (1 - reserve_factor)
        const borrowApy: u64 = this.borrowApyBps.value;
        const reserveFactor: u64 = this.reserveFactor.value;

        if (u256.eq(utilizationBps, u256.Zero)) return 0;

        const util: u64 = u256.toU64(utilizationBps);
        const gross: u64 = (borrowApy * util) / 10000;
        const netFactor: u64 = 10000 - reserveFactor;
        return (gross * netFactor) / 10000;
    }

    private _computeBorrowApy(utilizationBps: u256): u64 {
        // borrow_apy = base_borrow_apy * (1 + utilization_multiplier)
        const base: u64 = this.borrowApyBps.value;
        const util: u64 = u256.toU64(utilizationBps);
        // Kink model: steep increase after 80% utilization
        if (util > 8000) {
            const excess: u64 = util - 8000;
            return base + (excess * 5); // 5x slope above kink
        }
        return base + (base * util) / 20000;
    }
}
