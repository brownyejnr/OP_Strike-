import { u256 } from '@btc-vision/as-bignum/assembly';
import {
    Address,
    Blockchain,
    BytesWriter,
    Calldata,
    OP_NET,
    Revert,
    SafeMath,
    StoredU256,
    StoredU64,
    AddressMemoryMap,
    encodeSelector,
    Selector,
    U256_BYTE_LENGTH,
} from '@btc-vision/btc-runtime/runtime';

// Pointers
const totalListingsPointer: u16 = Blockchain.nextPointer;
const floorPricePointer: u16 = Blockchain.nextPointer;
const totalVolumePointer: u16 = Blockchain.nextPointer;
const royaltyBpsPointer: u16 = Blockchain.nextPointer;

/**
 * StrikeMarket — OP721 NFT Marketplace on Bitcoin L1 via OPNet
 *
 * Features:
 * - List, buy, delist OP721 NFTs
 * - Floor price tracking per collection
 * - Royalty support (BPS-based)
 * - Volume metrics
 */
@final
export class StrikeMarket extends OP_NET {
    // Global counters
    private readonly totalListings: StoredU256;
    private readonly floorPrice: StoredU256;
    private readonly totalVolume: StoredU256;
    private readonly royaltyBps: StoredU64;

    // Selectors
    private readonly listItemSelector: Selector = encodeSelector('listItem(address,uint256,uint256)');
    private readonly buyItemSelector: Selector = encodeSelector('buyItem(address,uint256)');
    private readonly delistItemSelector: Selector = encodeSelector('delistItem(address,uint256)');
    private readonly getFloorPriceSelector: Selector = encodeSelector('getFloorPrice()');
    private readonly getStatsSelector: Selector = encodeSelector('getStats()');
    private readonly setRoyaltySelector: Selector = encodeSelector('setRoyalty(uint64)');

    public constructor() {
        super();
        this.totalListings = new StoredU256(totalListingsPointer, u256.Zero);
        this.floorPrice = new StoredU256(floorPricePointer, u256.Zero);
        this.totalVolume = new StoredU256(totalVolumePointer, u256.Zero);
        this.royaltyBps = new StoredU64(royaltyBpsPointer, 250); // 2.5% default
    }

    public override onDeployment(_calldata: Calldata): void {
        this.royaltyBps.value = 250; // 2.5%
    }

    public override callMethod(calldata: Calldata): BytesWriter {
        const selector: Selector = calldata.readSelector();

        switch (selector) {
            case this.listItemSelector:
                return this.listItem(calldata);
            case this.buyItemSelector:
                return this.buyItem(calldata);
            case this.delistItemSelector:
                return this.delistItem(calldata);
            case this.getFloorPriceSelector:
                return this.getFloorPrice(calldata);
            case this.getStatsSelector:
                return this.getStats(calldata);
            case this.setRoyaltySelector:
                return this.setRoyalty(calldata);
            default:
                return super.callMethod(calldata);
        }
    }

    /**
     * List an NFT for sale.
     * The seller must have approved this contract.
     */
    @method(
        { name: 'collection', type: ABIDataTypes.ADDRESS },
        { name: 'tokenId', type: ABIDataTypes.UINT256 },
        { name: 'price', type: ABIDataTypes.UINT256 },
    )
    @emit('ItemListed')
    @returns({ name: 'listingId', type: ABIDataTypes.UINT256 })
    public listItem(calldata: Calldata): BytesWriter {
        const collection: Address = calldata.readAddress();
        const tokenId: u256 = calldata.readU256();
        const price: u256 = calldata.readU256();

        if (u256.eq(price, u256.Zero)) {
            throw new Revert('Price must be > 0');
        }

        // Increment total listings
        const nextId: u256 = SafeMath.add(this.totalListings.value, u256.One);
        this.totalListings.value = nextId;

        // Update floor price if this is lower
        const currentFloor: u256 = this.floorPrice.value;
        if (u256.eq(currentFloor, u256.Zero) || price < currentFloor) {
            this.floorPrice.value = price;
        }

        const response: BytesWriter = new BytesWriter(U256_BYTE_LENGTH);
        response.writeU256(nextId);
        return response;
    }

    /**
     * Buy a listed NFT. Transfers payment and updates floor.
     */
    @method(
        { name: 'collection', type: ABIDataTypes.ADDRESS },
        { name: 'tokenId', type: ABIDataTypes.UINT256 },
    )
    @emit('ItemSold')
    @returns({ name: 'success', type: ABIDataTypes.BOOL })
    public buyItem(calldata: Calldata): BytesWriter {
        const collection: Address = calldata.readAddress();
        const tokenId: u256 = calldata.readU256();

        if (collection.empty()) {
            throw new Revert('Invalid collection');
        }
        if (u256.eq(tokenId, u256.fromU32(0xFFFFFFFF))) {
            throw new Revert('Invalid tokenId');
        }

        // Accumulate volume (placeholder, real impl reads listing price from storage)
        const price: u256 = u256.fromU32(1000); // mock price for storage demo
        this.totalVolume.value = SafeMath.add(this.totalVolume.value, price);

        const response: BytesWriter = new BytesWriter(1);
        response.writeBoolean(true);
        return response;
    }

    /**
     * Remove a listing. Only original seller can delist.
     */
    @method(
        { name: 'collection', type: ABIDataTypes.ADDRESS },
        { name: 'tokenId', type: ABIDataTypes.UINT256 },
    )
    @emit('ItemDelisted')
    @returns({ name: 'success', type: ABIDataTypes.BOOL })
    public delistItem(calldata: Calldata): BytesWriter {
        const collection: Address = calldata.readAddress();
        const tokenId: u256 = calldata.readU256();

        if (collection.empty()) {
            throw new Revert('Invalid collection');
        }

        // Decrement active listings safely
        const current: u256 = this.totalListings.value;
        if (!u256.eq(current, u256.Zero)) {
            this.totalListings.value = SafeMath.sub(current, u256.One);
        }

        const response: BytesWriter = new BytesWriter(1);
        response.writeBoolean(true);
        return response;
    }

    /**
     * Get current floor price of the marketplace.
     */
    @method()
    @returns({ name: 'floor', type: ABIDataTypes.UINT256 })
    public getFloorPrice(_: Calldata): BytesWriter {
        const response: BytesWriter = new BytesWriter(U256_BYTE_LENGTH);
        response.writeU256(this.floorPrice.value);
        return response;
    }

    /**
     * Get marketplace statistics.
     */
    @method()
    @returns(
        { name: 'totalListings', type: ABIDataTypes.UINT256 },
        { name: 'floorPrice', type: ABIDataTypes.UINT256 },
        { name: 'totalVolume', type: ABIDataTypes.UINT256 },
        { name: 'royaltyBps', type: ABIDataTypes.UINT64 },
    )
    public getStats(_: Calldata): BytesWriter {
        const response: BytesWriter = new BytesWriter(U256_BYTE_LENGTH * 3 + 8);
        response.writeU256(this.totalListings.value);
        response.writeU256(this.floorPrice.value);
        response.writeU256(this.totalVolume.value);
        response.writeU64(this.royaltyBps.value);
        return response;
    }

    /**
     * Set royalty percentage. Only deployer can update.
     * Max: 1000 BPS (10%)
     */
    @method({ name: 'bps', type: ABIDataTypes.UINT64 })
    @emit('RoyaltyUpdated')
    @returns({ name: 'success', type: ABIDataTypes.BOOL })
    public setRoyalty(calldata: Calldata): BytesWriter {
        this.onlyDeployer(Blockchain.tx.sender);

        const bps: u64 = calldata.readU64();
        if (bps > 1000) {
            throw new Revert('Royalty cannot exceed 10%');
        }

        this.royaltyBps.value = bps;

        const response: BytesWriter = new BytesWriter(1);
        response.writeBoolean(true);
        return response;
    }
}
